package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DeleteCustomerStepDefinition {

@Given("^User is on deleteCustomerPage Page$")
public void user_is_on_deleteCustomerPage_Page() throws Throwable {
 
}

@When("^User enter his correct credentials and click on delete customer button$")
public void user_enter_his_correct_credentials_and_click_on_delete_customer_button() throws Throwable {
    
}

@Then("^User is redirected to deleteCustomerPage page and message gets displayed$")
public void user_is_redirected_to_deleteCustomerPage_page_and_message_gets_displayed() throws Throwable {
    
}
}
