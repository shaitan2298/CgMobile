package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetCustomerAllPostpaidAccountsDetailsStepDefinition {
	@Given("^User is on getCustomerAllPostpaidAccountsDetailsPage Page$")
	public void user_is_on_getCustomerAllPostpaidAccountsDetailsPage_Page() throws Throwable {
	
	}

	@When("^User enter his correct credentials and click on postpaid account details button$")
	public void user_enter_his_correct_credentials_and_click_on_postpaid_account_details_button() throws Throwable {
	 
	}

	@Then("^User is redirected to getCustomerAllPostpaidAccountsDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerAllPostpaidAccountsDetailsPage_page_and_details_gets_displayed() throws Throwable {
	
	}
}
