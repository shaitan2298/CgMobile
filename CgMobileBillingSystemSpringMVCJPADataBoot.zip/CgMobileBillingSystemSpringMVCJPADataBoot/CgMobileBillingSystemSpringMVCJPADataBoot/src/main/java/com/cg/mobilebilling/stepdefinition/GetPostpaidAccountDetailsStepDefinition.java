package com.cg.mobilebilling.stepdefinition;

public class GetPostpaidAccountDetailsStepDefinition {

}
